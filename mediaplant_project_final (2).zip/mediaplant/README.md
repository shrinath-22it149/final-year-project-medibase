# 🌿 MediPlant AI — Final Year Project
### Smart Medicinal Plant Identification Using Ensemble Deep Learning

---

## 📋 PROJECT OVERVIEW

MediPlant AI is a complete web application for identifying and classifying medicinal plants using Ensemble Deep Learning (VGG16 + ResNet50 + InceptionV3). Built with Streamlit and TensorFlow.

**Key Features:**
- 🔍 Plant identification from leaf images
- 📊 Ensemble model (VGG16 + ResNet50 + InceptionV3) — 95%+ accuracy
- 🌡️ Grad-CAM explainability heatmaps
- 💊 Medicinal uses, compounds, preparation methods
- ⚠️ Toxicity and safety warnings
- 📄 PDF report download
- 🤖 AI Chatbot (MediBot)
- ⚖️ Plant comparison tool
- 📊 Model analytics dashboard
- 👤 User authentication (login/register)
- 📋 Identification history

---

## 🗂️ PROJECT STRUCTURE

```
mediaplant/
├── app.py                          ← Main home page
├── requirements.txt                ← Python packages
├── README.md                       ← This file
│
├── .streamlit/
│   └── config.toml                 ← Theme settings (green)
│
├── pages/
│   ├── 1_🔍_Identify.py           ← Plant identification (MAIN)
│   ├── 2_🌿_Database.py           ← Plant database browser
│   ├── 3_📊_Analytics.py          ← Model analytics & charts
│   ├── 4_⚖️_Compare.py            ← Compare 2-3 plants
│   ├── 5_🤖_Chatbot.py            ← AI chatbot (MediBot)
│   ├── 6_📋_History.py            ← User history & saved plants
│   └── 7_👤_Profile.py            ← Login, register, dashboard
│
├── model/
│   ├── train_model.py              ← Model training script
│   ├── predictor.py                ← Prediction engine
│   ├── gradcam.py                  ← Grad-CAM explainability
│   └── saved_model/                ← Trained model files (after training)
│       ├── ensemble_model.h5
│       ├── hybrid_model.h5
│       ├── ensemble_metrics.json
│       └── ensemble_history.pkl
│
├── database/
│   ├── db_operations.py            ← All database operations
│   └── mediaplant.db               ← SQLite database (auto-created)
│
├── data/
│   ├── plants_info.json            ← Plant information database
│   ├── class_labels.json           ← Model class names
│   └── dataset/                    ← PUT YOUR DATASET HERE
│       ├── train/
│       │   ├── Tulsi/
│       │   ├── Neem/
│       │   └── ... (one folder per plant)
│       └── test/
│           ├── Tulsi/
│           ├── Neem/
│           └── ...
│
├── utils/
│   ├── helpers.py                  ← UI helpers and CSS
│   └── report_generator.py         ← PDF report generation
│
└── assets/
    └── images/                     ← Plant images (optional)
```

---

## 🚀 STEP-BY-STEP SETUP GUIDE (A to Z)

### STEP 1: Install Python
- Download Python 3.10 or 3.11 from https://python.org
- Make sure to check ✅ "Add Python to PATH" during installation
- Verify: Open terminal and type `python --version`

---

### STEP 2: Download This Project
- Extract the zip file to a folder, e.g.: `C:\Users\YourName\mediaplant`
- Or if using Git: `git clone <your-repo-url>`

---

### STEP 3: Create Virtual Environment (Recommended)
```bash
# Open terminal/command prompt
cd mediaplant

# Create virtual environment
python -m venv venv

# Activate it
# Windows:
venv\Scripts\activate
# Mac/Linux:
source venv/bin/activate
```

---

### STEP 4: Install All Requirements
```bash
pip install -r requirements.txt
```
⏳ This takes 5-10 minutes. Be patient!

---

### STEP 5: Download Dataset from Kaggle

#### Option A — Indian Medicinal Leaf Dataset (Recommended)
1. Go to: https://www.kaggle.com/datasets/warcoder/indian-medicinal-leaves-image-datasets
2. Click **Download** (you need a free Kaggle account)
3. Extract the zip
4. Organize into this structure:

```
data/dataset/
├── train/
│   ├── Tulsi/          ← All Tulsi images here
│   ├── Neem/           ← All Neem images here
│   ├── Aloe_Vera/
│   ├── Ginger/
│   └── ... (one folder per plant class)
└── test/
    ├── Tulsi/
    ├── Neem/
    └── ...
```

#### Option B — Kaggle Medicinal Plants (More Images)
1. Go to: https://www.kaggle.com/datasets/aryashah2k/indian-medicinal-leaves-dataset
2. Download and organize same as above

#### How to Split Dataset:
- Put 80% of each plant's images in `train/PlantName/`
- Put 20% in `test/PlantName/`
- Each plant should have at least 50 images

---

### STEP 6: Train the Model
```bash
# Make sure you are in the mediaplant folder
python model/train_model.py
```

**This will:**
- Train Ensemble Model (VGG16 + ResNet50 + InceptionV3)
- Train Hybrid CNN-LSTM Model
- Save models to `model/saved_model/`
- Generate training plots
- Show accuracy, precision, recall, F1-score

⏳ **Training Time:**
- With GPU: 30-60 minutes
- Without GPU (CPU only): 3-6 hours

**To speed up training:**
```bash
# Check if GPU is available
python -c "import tensorflow as tf; print(tf.config.list_physical_devices('GPU'))"
```

---

### STEP 7: Run the Web Application
```bash
streamlit run app.py
```

✅ The app will open at: **http://localhost:8501**

---

### STEP 8: Use the Application

1. **Home Page** — Overview and navigation
2. **Identify Plant** — Upload a leaf image and click "Identify Plant"
3. **Plant Database** — Browse all medicinal plants
4. **Analytics** — View model performance metrics
5. **Compare Plants** — Compare 2-3 plants side by side
6. **MediBot** — Chat with AI about plants
7. **History** — View past identifications (login required)
8. **Profile** — Login/Register

**Demo Login:** username: `demo`, password: `demo123`

---

## ⚠️ RUNNING WITHOUT TRAINING (Demo Mode)

You can run the app without training the model first!

- The app will show a **Demo Mode** warning
- Predictions will be simulated (random)
- All other features work normally
- This is useful for testing the UI

---

## 🌐 DEPLOYING ONLINE (Free)

### Streamlit Cloud (Easiest — Free)
1. Create account at https://streamlit.io
2. Push code to GitHub
3. Connect GitHub repo on Streamlit Cloud
4. App is live at `https://yourname-mediaplant.streamlit.app`

### Render (Free)
1. Create account at https://render.com
2. New Web Service → Connect GitHub
3. Start command: `streamlit run app.py --server.port $PORT`

---

## 🤖 OPTIONAL: AI Chatbot with Gemini

To use Google Gemini AI in the chatbot:
1. Get free API key from: https://aistudio.google.com
2. In the Chatbot page sidebar, enter your API key
3. The chatbot will use Gemini for smarter responses

---

## 📊 EXPECTED MODEL PERFORMANCE

| Model            | Accuracy | Precision | Recall | F1-Score |
|------------------|----------|-----------|--------|----------|
| VGG16 Alone      | 91-94%   | 90-93%    | 91-93% | 90-93%   |
| ResNet50 Alone   | 92-96%   | 91-95%    | 92-95% | 91-95%   |
| InceptionV3      | 91-95%   | 90-94%    | 91-94% | 90-94%   |
| CNN-LSTM Hybrid  | 80-88%   | 79-87%    | 80-87% | 79-87%   |
| **Ensemble**     | **95-99%** | **94-98%** | **95-98%** | **94-98%** |

---

## 🛠️ TROUBLESHOOTING

| Problem | Solution |
|---------|----------|
| `ModuleNotFoundError` | Run `pip install -r requirements.txt` again |
| `Model file not found` | Run `python model/train_model.py` first |
| `Dataset not found` | Check `data/dataset/train/` folder structure |
| App opens but crashes | Check terminal for error messages |
| Training too slow | Reduce batch_size to 16 in `train_model.py` |
| Out of memory | Reduce image_size to 128 or batch_size to 8 |
| Grad-CAM not working | Normal — some model configs don't support it |

---

## 📦 ALL PACKAGES USED

| Package | Purpose |
|---------|---------|
| streamlit | Web application framework |
| tensorflow | Deep learning model training |
| opencv-python | Image processing |
| Pillow | Image handling |
| numpy | Array operations |
| pandas | Data manipulation |
| plotly | Interactive charts |
| matplotlib | Static plots |
| scikit-learn | Evaluation metrics |
| fpdf2 | PDF report generation |
| google-generativeai | Gemini AI chatbot |
| bcrypt | Password hashing |

---

## 👥 PROJECT TEAM

- Built as Final Year Project
- Department of Computer Science
- Based on IEEE Research Paper: "Investigation of Deep Learning Techniques Used in Medicinal Plants Identification and Classification" (2025)

---

## 📚 REFERENCES

1. Garang Ok et al., "Investigation of Deep Learning Techniques Used in Medicinal Plants Identification and Classification," IEEE Access, 2025
2. Simonyan & Zisserman, "Very Deep Convolutional Networks (VGG)," 2014
3. He et al., "Deep Residual Learning for Image Recognition (ResNet)," 2016
4. Szegedy et al., "Rethinking the Inception Architecture (InceptionV3)," 2016
5. Selvaraju et al., "Grad-CAM: Visual Explanations from Deep Networks," 2017

---

*🌿 MediPlant AI — Preserving Indigenous Knowledge Through Artificial Intelligence*
