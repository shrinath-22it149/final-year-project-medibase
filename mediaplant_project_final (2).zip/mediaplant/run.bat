@echo off
title MediPlant AI
cd /d "%~dp0"

REM Suppress ALL numpy/runtime warnings at OS level
set PYTHONWARNINGS=ignore::RuntimeWarning:numpy
set PYTHONWARNINGS=ignore::RuntimeWarning
set TF_CPP_MIN_LOG_LEVEL=3
set TF_ENABLE_ONEDNN_OPTS=0
set MPLBACKEND=Agg

echo  =============================================
echo    MediPlant AI - Starting...
echo    Open: http://localhost:8501
echo  =============================================
echo.
streamlit run app.py --logger.level=error
pause
