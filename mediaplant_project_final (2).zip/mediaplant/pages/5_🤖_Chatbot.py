import os, sys
import warnings, os as _os
warnings.filterwarnings("ignore")
_os.environ["PYTHONWARNINGS"] = "ignore"
_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if _ROOT not in sys.path:
    sys.path.insert(0, _ROOT)
os.chdir(_ROOT)

import streamlit as st
import json

st.set_page_config(page_title="MediBot | MediPlant AI", page_icon="🤖", layout="wide")

st.markdown("""
<style>
.main{background:#FAFFFE;}
h1,h2,h3{color:#2E8B57!important;}
section[data-testid="stSidebar"]{background:linear-gradient(180deg,#1a3a2a,#2E8B57);}
section[data-testid="stSidebar"] *{color:white!important;}
div.stButton>button{background:linear-gradient(135deg,#2E8B57,#3CB371);
  color:white;border:none;border-radius:8px;font-weight:bold;}
#MainMenu{visibility:hidden;}footer{visibility:hidden;}
</style>
""", unsafe_allow_html=True)

if "user"          not in st.session_state: st.session_state.user = None
if "chat_messages" not in st.session_state: st.session_state.chat_messages = []

with st.sidebar:
    st.markdown("## 🌿 MediPlant AI")
    st.markdown("---")
    if st.session_state.user:
        st.success(f"👤 {st.session_state.user['username']}")
    st.markdown("---")
    st.page_link("app.py",                 label="🏠 Home")
    st.page_link("pages/1_🔍_Identify.py", label="🔍 Identify Plant")
    st.markdown("---")
    st.markdown("### 🤖 Gemini API (Optional)")
    gemini_key = st.text_input("Paste API Key here", type="password",
                               help="Free key at https://aistudio.google.com")
    if st.button("🗑️ Clear Chat", use_container_width=True):
        st.session_state.chat_messages = []
        st.rerun()

@st.cache_data
def load_plants():
    path = os.path.join(_ROOT, "data", "plants_info.json")
    with open(path, encoding="utf-8") as f:
        return json.load(f)["plants"]

def find_plant(name):
    try:
        plants = load_plants()
        nl = name.lower().strip()
        for p in plants:
            if nl in p["common_name"].lower() or p["common_name"].lower() in nl:
                return p
    except Exception:
        pass
    return None

def kb_response(user_input):
    """Knowledge base chatbot — works with no API key."""
    try:
        plants = load_plants()
    except Exception:
        return "❌ Could not load plant data. Please check `data/plants_info.json` exists."

    ui = user_input.lower().strip()

    # Greetings
    if any(k in ui for k in ["hello","hi ","hey","namaste","good morning","good evening","start"]):
        return ("👋 **Hello! I'm MediBot!** 🌿\n\n"
                "I'm your AI medicinal plant assistant. Ask me about:\n\n"
                "🌿 **Plant benefits & uses** — 'What is Tulsi used for?'\n"
                "⚠️ **Safety & warnings** — 'Is Neem safe for pregnancy?'\n"
                "📋 **Preparation methods** — 'How to make Ginger tea?'\n"
                "🏥 **Health conditions** — 'Plants for diabetes?'\n"
                "🔬 **Active compounds** — 'What compounds are in Turmeric?'\n\n"
                "What would you like to know? 🌿")

    # About the app
    if any(k in ui for k in ["model","accuracy","how work","ai","deep learning","mediaplant","this app","about"]):
        return ("**🤖 About MediPlant AI:**\n\n"
                "MediPlant AI uses **Ensemble Deep Learning** combining:\n"
                "• **VGG16** — texture & edge features\n"
                "• **ResNet50** — deep residual features\n"
                "• **InceptionV3** — multi-scale features\n\n"
                "Combined accuracy: **95%+** on 30 medicinal plant species.\n\n"
                "Also features **Grad-CAM explainability** to show which leaf parts the AI focused on.")

    # List all plants
    if any(k in ui for k in ["list","all plant","show plant","how many plant","which plant"]):
        items = "\n".join([f"🌿 **{p['common_name']}** — *{p['scientific_name']}*" for p in plants])
        return f"**Plants in my database ({len(plants)}):**\n\n{items}\n\n💡 Ask me about any of these!"

    # Match a specific plant name
    for plant in plants:
        pname = plant["common_name"].lower()
        sci   = plant.get("scientific_name","").lower()
        tamil = plant.get("tamil_name","").lower()
        if pname in ui or sci in ui or (tamil and tamil in ui):
            if any(k in ui for k in ["use","treat","help","good for","benefit","what is","about","tell"]):
                uses = "\n".join([f"✅ {u}" for u in plant["medicinal_uses"]])
                return (f"## 🌿 {plant['common_name']}\n"
                        f"*{plant['scientific_name']}* | Tamil: {plant.get('tamil_name','N/A')}\n\n"
                        f"**{plant.get('description','')}**\n\n"
                        f"**Medicinal Uses:**\n{uses}\n\n"
                        f"**Safety:** {plant['safety_info']}")
            if any(k in ui for k in ["safe","toxic","danger","warn","pregnan","child","side effect"]):
                warns = "\n".join([f"⚠️ {w}" for w in plant.get("warnings",[])])
                return (f"## ⚠️ Safety — {plant['common_name']}\n\n"
                        f"**Toxicity Level:** {plant['toxicity_level']}\n\n"
                        f"{plant['safety_info']}\n\n"
                        + (f"**Specific Warnings:**\n{warns}" if warns else "✅ No major safety warnings."))
            if any(k in ui for k in ["prepare","how to","make","recipe","dose","dosage","consume","take","drink"]):
                methods = "\n".join([f"🌿 {m}" for m in plant.get("preparation_methods",[])])
                return f"## 📋 How to Use — {plant['common_name']}\n\n{methods}"
            if any(k in ui for k in ["compound","chemical","contain","active","ingredient","constituent"]):
                comps = "\n".join([f"• **{c}**" for c in plant.get("active_compounds",[])])
                return f"## 🧪 Active Compounds in {plant['common_name']}\n\n{comps}"
            # General plant info
            return (f"## 🌿 {plant['common_name']}\n"
                    f"*{plant['scientific_name']}*\n\n"
                    f"Tamil: **{plant.get('tamil_name','N/A')}** | Family: **{plant['family']}**\n\n"
                    f"{plant.get('description','')}\n\n"
                    f"**Key Uses:** {', '.join(plant['medicinal_uses'][:4])}\n"
                    f"**Toxicity:** {plant['toxicity_level']} | "
                    f"**Availability:** {plant.get('availability','N/A')}\n\n"
                    f"💬 Ask me specifically about uses, safety, preparation, or compounds!")

    # Condition-based lookup
    condition_map = {
        "diabetes"    : ["Giloy","Turmeric","Moringa","Aloe Vera","Neem"],
        "immunity"    : ["Tulsi","Amla","Giloy","Moringa","Ashwagandha"],
        "stress"      : ["Ashwagandha","Brahmi","Tulsi"],
        "anxiety"     : ["Ashwagandha","Brahmi","Tulsi"],
        "memory"      : ["Brahmi","Ashwagandha"],
        "brain"       : ["Brahmi","Ashwagandha"],
        "sleep"       : ["Ashwagandha","Brahmi"],
        "insomnia"    : ["Ashwagandha","Brahmi"],
        "skin"        : ["Neem","Aloe Vera","Turmeric"],
        "acne"        : ["Neem","Turmeric","Aloe Vera"],
        "hair"        : ["Brahmi","Amla","Aloe Vera"],
        "digestion"   : ["Ginger","Aloe Vera","Moringa"],
        "stomach"     : ["Ginger","Aloe Vera"],
        "cold"        : ["Tulsi","Ginger","Turmeric"],
        "flu"         : ["Tulsi","Ginger","Giloy"],
        "cough"       : ["Tulsi","Ginger"],
        "fever"       : ["Tulsi","Giloy","Neem"],
        "inflammation": ["Turmeric","Ginger","Neem"],
        "arthritis"   : ["Turmeric","Ginger","Ashwagandha"],
        "joint"       : ["Turmeric","Ginger"],
        "cholesterol" : ["Moringa","Ginger","Turmeric"],
        "weight"      : ["Moringa","Ginger","Turmeric"],
        "liver"       : ["Amla","Giloy","Neem"],
        "blood pressure": ["Amla","Giloy","Moringa"],
        "cancer"      : ["Amla","Neem","Moringa"],
        "wound"       : ["Aloe Vera","Neem","Turmeric"],
        "pain"        : ["Ginger","Turmeric","Ashwagandha"],
    }
    for cond, pnames in condition_map.items():
        if cond in ui:
            out = f"## 🌿 Plants that may help with **{cond}**:\n\n"
            for pn in pnames:
                p = find_plant(pn)
                if p:
                    out += f"✅ **{p['common_name']}** — {p['medicinal_uses'][0]}\n"
                else:
                    out += f"✅ **{pn}**\n"
            out += "\n\n⚕️ *Always consult a qualified doctor before using any herbal remedy.*"
            return out

    # Fallback
    plant_list = ", ".join([p["common_name"] for p in plants])
    return (f"🤔 I didn't quite understand that. Let me help you better!\n\n"
            f"**Try asking:**\n"
            f"• 'What is Tulsi used for?'\n"
            f"• 'Is Neem safe during pregnancy?'\n"
            f"• 'How to prepare Ginger tea?'\n"
            f"• 'What plants help with diabetes?'\n"
            f"• 'What compounds are in Turmeric?'\n\n"
            f"**Plants I know:** {plant_list}")

def gemini_response(user_input, api_key):
    """Use Gemini API if key is provided, else fall back to knowledge base."""
    try:
        import google.generativeai as genai
        genai.configure(api_key=api_key)
        model  = genai.GenerativeModel("gemini-1.5-flash")
        prompt = (
            "You are MediBot, an expert AI assistant for Ayurvedic and medicinal plants. "
            "Answer helpfully, concisely, and accurately. "
            "Always add safety disclaimers when discussing medicinal uses. "
            "Format your response with markdown for readability.\n\n"
            f"User question: {user_input}"
        )
        response = model.generate_content(prompt)
        return response.text
    except Exception:
        return kb_response(user_input)

# ── Page UI ────────────────────────────────────────────────────────────────────
st.title("🤖 MediBot — Medicinal Plant AI Chatbot")
st.markdown("Ask me anything about medicinal plants, their uses, safety, and preparation!")

if gemini_key:
    st.success("✅ Gemini AI connected — Enhanced responses active")
else:
    st.info("💡 Running in **Knowledge Base mode**. Add a Gemini API key in the sidebar for enhanced AI responses.")

st.divider()

# Quick question buttons
st.markdown("**💡 Quick Questions — click to ask:**")
qcols = st.columns(5)
quick_qs = [
    "What is Tulsi used for?",
    "Is Neem safe?",
    "How to use Aloe Vera?",
    "Plants for diabetes?",
    "Best plants for immunity?"
]
quick_pressed = None
for col, q in zip(qcols, quick_qs):
    with col:
        if st.button(q, use_container_width=True):
            quick_pressed = q

st.divider()

# Welcome message on first load
if not st.session_state.chat_messages:
    st.session_state.chat_messages.append({
        "role": "assistant",
        "content": ("👋 **Hello! I'm MediBot!** 🌿\n\n"
                    "I can answer questions about **10 medicinal plants** — their uses, safety, "
                    "preparation methods, active compounds, and which plants help specific health conditions.\n\n"
                    "Try asking: *'What is Tulsi good for?'* or *'Plants for diabetes?'*")
    })

# Display chat history
for msg in st.session_state.chat_messages:
    avatar = "🤖" if msg["role"] == "assistant" else "👤"
    with st.chat_message(msg["role"], avatar=avatar):
        st.markdown(msg["content"])

# Handle quick question click
if quick_pressed:
    st.session_state.chat_messages.append({"role": "user", "content": quick_pressed})
    with st.spinner("🌿 Thinking..."):
        resp = gemini_response(quick_pressed, gemini_key) if gemini_key else kb_response(quick_pressed)
    st.session_state.chat_messages.append({"role": "assistant", "content": resp})
    try:
        from database.db_operations import save_chat_message
        if st.session_state.user:
            save_chat_message(st.session_state.user["id"], "user",      quick_pressed)
            save_chat_message(st.session_state.user["id"], "assistant", resp)
    except Exception:
        pass
    st.rerun()

# Chat input
if user_input := st.chat_input("Ask about any medicinal plant..."):
    st.session_state.chat_messages.append({"role": "user", "content": user_input})
    with st.spinner("🌿 Thinking..."):
        resp = gemini_response(user_input, gemini_key) if gemini_key else kb_response(user_input)
    st.session_state.chat_messages.append({"role": "assistant", "content": resp})
    try:
        from database.db_operations import save_chat_message
        if st.session_state.user:
            save_chat_message(st.session_state.user["id"], "user",      user_input)
            save_chat_message(st.session_state.user["id"], "assistant", resp)
    except Exception:
        pass
    st.rerun()
